﻿namespace $safeprojectname$.ViewModels
{
    public class MainViewModel
    {
    }
}
